package ifsc;

public class Pessoa {

	public Long cpf;
	public String nome;
	public String data;

}
